"""Train-anchored conditional variational whole-character stroke generator.
Neural residuals around learned training-only mean shapes. No autoregressive rollout.
"""
from pathlib import Path
from dataclasses import dataclass, asdict
import json, math, random, time, copy
import numpy as np
import torch
from torch import nn
import handwriting_common as common
seed_all=common.seed_all
plot_strokes=common.plot_strokes
MODEL_FORMAT='ink-study-shape-v2'

@dataclass
class Config:
    seed:int=2026
    points:int=48
    latent:int=8
    hidden:int=192
    embedding:int=32
    batch_size:int=64
    learning_rate:float=.001
    max_epochs:int=200
    patience:int=40
    kl_weight:float=.002
    preview_every:int=25
    spatial_step:float=.06
    max_steps:int=256


def signature(strokes):
    lengths=[float(np.linalg.norm(np.diff(s[:,:2],axis=0),axis=1).sum()) for s in strokes]
    order=np.argsort(-np.array(lengths),kind='stable').tolist()
    longest=strokes[order[0]][:,:2];delta=longest[-1]-longest[0]
    extent=np.ptp(longest,axis=0).clip(.1)
    direction=[int(np.sign(v)) if abs(v)>.6 else 0 for v in delta/extent]
    return [len(strokes),order,direction]

def fixed(stroke,points):
    xy=stroke[:,:2]
    if len(xy)==1:return np.repeat(xy,points,axis=0)
    ds=np.r_[0,np.cumsum(np.linalg.norm(np.diff(xy,axis=0),axis=1))]
    keep=np.r_[True,np.diff(ds)>1e-8];xy=xy[keep];ds=ds[keep]
    if len(xy)==1:return np.repeat(xy,points,axis=0)
    t=np.linspace(0,ds[-1],points)
    return np.stack([np.interp(t,ds,xy[:,i]) for i in range(2)],axis=-1).astype('float32')

def prepare_data(path,cfg):
    records,base=common.prepare_data(path,cfg)
    train=[r for r in records if r['split']=='train'];max_strokes=max(len(r['strokes']) for r in train)
    def vector(r):
        a=np.zeros((max_strokes,cfg.points,2),dtype='float32')
        if len(r['strokes'])>max_strokes:return None
        for i,s in enumerate(r['strokes']):a[i]=fixed(s,cfg.points)
        return a
    by_key={}
    for r in train:
        key=json.dumps([r['label'],signature(r['strokes'])]);by_key.setdefault(key,[]).append(r)
    groups=[];keys={};means=[];scales=[];masks=[]
    for key,examples in sorted(by_key.items()):
        gid=len(groups);keys[key]=gid;n=len(examples[0]['strokes']);arr=np.stack([vector(r) for r in examples]);mu=arr.mean(0)
        # A scalar residual scale per group preserves x/y geometry and avoids tiny-coordinate division.
        scale=max(.04,float(np.sqrt(((arr[:,:n]-mu[:n])**2).mean())))
        mask=np.zeros_like(mu);mask[:n]=1
        groups.append({'label':examples[0]['label'],'signature':signature(examples[0]['strokes']),'count':len(examples),'strokes':n,'training_ids':[r['id'] for r in examples]})
        means.append(mu);scales.append(scale);masks.append(mask)
    encoded=[];unsupported=[]
    for r in records:
        key=json.dumps([r['label'],signature(r['strokes'])]);gid=keys.get(key)
        if gid is None:
            unsupported.append({'id':r['id'],'label':r['label'],'split':r['split'],'reason':'No matching training stroke structure'})
            continue
        a=vector(r);encoded.append({'id':r['id'],'label':r['label'],'split':r['split'],'group':gid,'target':((a-means[gid])/scales[gid])*masks[gid]})
    metadata={**base,'format':MODEL_FORMAT,'points':cfg.points,'max_strokes':max_strokes,'groups':groups,'unsupported':unsupported}
    stats={'means':torch.tensor(np.stack(means)),'scales':torch.tensor(scales,dtype=torch.float32),'masks':torch.tensor(np.stack(masks))}
    return records,encoded,metadata,stats

class ShapeModel(nn.Module):
    def __init__(self,cfg,stats):
        super().__init__();self.config=cfg
        for k,v in stats.items():self.register_buffer(k,v.clone())
        self.shape=tuple(stats['means'].shape[1:]);d=int(np.prod(self.shape));g=len(stats['means'])
        self.embedding=nn.Embedding(g,cfg.embedding)
        self.encoder=nn.Sequential(nn.Linear(d+cfg.embedding,cfg.hidden),nn.SiLU(),nn.Linear(cfg.hidden,cfg.hidden),nn.SiLU(),nn.Linear(cfg.hidden,2*cfg.latent))
        self.decoder=nn.Sequential(nn.Linear(cfg.latent+cfg.embedding,cfg.hidden),nn.SiLU(),nn.Linear(cfg.hidden,cfg.hidden),nn.SiLU(),nn.Linear(cfg.hidden,d))
        nn.init.zeros_(self.decoder[-1].weight);nn.init.zeros_(self.decoder[-1].bias)
    def encode(self,x,group):
        q=self.encoder(torch.cat([x.flatten(1),self.embedding(group)],-1));mu,lv=q.chunk(2,-1)
        return mu,lv.clamp(-6,2)
    def decode(self,z,group):
        residual=self.decoder(torch.cat([z,self.embedding(group)],-1)).reshape(-1,*self.shape)
        return 3*torch.tanh(residual/3)*self.masks[group]
    def forward(self,x,group,sample=True):
        mu,lv=self.encode(x,group);z=mu+torch.randn_like(mu)*(.5*lv).exp() if sample else mu
        return self.decode(z,group),mu,lv

def batch(rows,device):
    return torch.tensor(np.stack([r['target'] for r in rows]),device=device),torch.tensor([r['group'] for r in rows],dtype=torch.long,device=device)

def objective(model,x,group,pred,mu,lv):
    mask=model.masks[group];denom=mask.sum((1,2,3)).clamp_min(1)
    reconstruction=(((pred-x)**2*mask).sum((1,2,3))/denom).mean()
    slope=((((pred[:,:,1:]-pred[:,:,:-1])-(x[:,:,1:]-x[:,:,:-1]))**2*mask[:,:,1:]).sum((1,2,3))/denom).mean()
    kl=(-.5*(1+lv-mu.square()-lv.exp()).sum(-1)).mean()
    return reconstruction+.2*slope+model.config.kl_weight*kl

@torch.inference_mode()
def evaluate(model,rows,device):
    model.eval();sq=base_sq=0.;count=0
    for i in range(0,len(rows),model.config.batch_size):
        x,g=batch(rows[i:i+model.config.batch_size],device);pred,_,_=model(x,g,sample=False);mask=model.masks[g];scale=model.scales[g,None,None,None]
        sq+=float((((pred-x)*scale)**2*mask).sum());base_sq+=float(((x*scale)**2*mask).sum());count+=int(mask.sum())
    if not count:return {'rmse':None,'mean_shape_rmse':None,'examples':0}
    return {'rmse':math.sqrt(sq/count),'mean_shape_rmse':math.sqrt(base_sq/count),'examples':len(rows),'meaning':'Held-out reconstruction with input supplied, in x-height units; not free-generation quality.'}

@torch.inference_mode()
def build_latent_bank(model,rows,device):
    model.eval();result={}
    for i in range(0,len(rows),model.config.batch_size):
        chunk=rows[i:i+model.config.batch_size];x,g=batch(chunk,device);mu,_=model.encode(x,g)
        for row,z in zip(chunk,mu.cpu().tolist()):result.setdefault(str(row['group']),[]).append(z)
    return result

@torch.inference_mode()
def generate(model,meta,bank,char,seed=1,variation=.7):
    if not 0<=variation<=1.5:raise ValueError('Variation must be in [0,1.5].')
    candidates=[i for i,g in enumerate(meta['groups']) if g['label']==char]
    if not candidates:raise ValueError(f'Unsupported character: {char!r}')
    rng=np.random.default_rng(seed);weights=np.array([meta['groups'][i]['count'] for i in candidates],float);weights/=weights.sum()
    gid=int(rng.choice(candidates,p=weights));latents=np.array(bank[str(gid)],dtype='float32')
    # Interpolate two training posterior centres; generation never copies point arrays.
    a,b=rng.integers(len(latents),size=2);alpha=float(rng.uniform(.15,.85));z=(1-alpha)*latents[a]+alpha*latents[b]
    z+=rng.normal(0,.10,size=z.shape).astype('float32')*latents.std(0)
    device=next(model.parameters()).device;g=torch.tensor([gid],device=device);zt=torch.tensor(z[None],device=device)
    was_training=model.training;model.eval()
    residual=model.decode(zt,g)[0]*variation
    xy=(model.means[gid]+model.scales[gid]*residual).cpu().numpy();model.train(was_training)
    strokes=[np.c_[s,np.full(len(s),.5)].astype('float32') for s in xy[:meta['groups'][gid]['strokes']]]
    return {'label':char,'seed':seed,'variation':variation,'group':gid,'strokes':strokes,'stop':'fixed_stroke_structure','points':sum(map(len,strokes)),'training_examples_in_group':len(latents)}

def comparison(model,meta,bank,records,chars='abegijyAM37#',variation=.7):
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(len(chars),4,figsize=(9,2*len(chars)),squeeze=False);diag=[]
    for row,ch in enumerate(chars):
        refs=[r for r in records if r['label']==ch]
        plot_strokes(axes[row,0],next(r['strokes'] for r in refs if r['split']=='train'),f'{ch}: training original')
        val=next((r for r in refs if r['split']=='validation'),None)
        if val:plot_strokes(axes[row,1],val['strokes'],'validation original')
        else:axes[row,1].axis('off')
        for col in (2,3):
            g=generate(model,meta,bank,ch,seed=101+row*2+col,variation=variation)
            plot_strokes(axes[row,col],g['strokes'],'neural variation');diag.append({k:v for k,v in g.items() if k!='strokes'})
    fig.tight_layout();return fig,diag

def svg_text(model,meta,bank,text,seed=31415,variation=.7):
    import types
    # Reuse the reviewed separated-print layout with this generator only.
    def adapter(m,metadata,char,seed,temperature):return generate(m,metadata,bank,char,seed,temperature)
    render=types.FunctionType(common.svg_text.__code__,{**common.__dict__,'generate':adapter},argdefs=common.svg_text.__defaults__)
    return render(model,meta,text,seed=seed,temperature=variation)

def load_model(path,device='cpu'):
    ck=torch.load(path,map_location='cpu',weights_only=True)
    if ck.get('format')!=MODEL_FORMAT:raise ValueError('This notebook requires a shape-v2 checkpoint; v1/recurrent checkpoints are incompatible.')
    cfg=Config(**ck['config']);stats={k:ck['model'][k] for k in ('means','scales','masks')};model=ShapeModel(cfg,stats).to(device);model.load_state_dict(ck['model']);model.eval()
    return model,ck['metadata'],ck['bank'],ck

def fit(model,encoded,meta,cfg,out,device,records,resume=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);tr=[r for r in encoded if r['split']=='train'];val=[r for r in encoded if r['split']=='validation']
    if not tr or not val:raise ValueError('Training and validation examples are required.')
    opt=torch.optim.AdamW(model.parameters(),lr=cfg.learning_rate,weight_decay=1e-4)
    scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,patience=15,factor=.5,min_lr=1e-5)
    history=[];best=float('inf');bad=0;start=0
    if resume:
        ck=torch.load(resume,map_location='cpu',weights_only=True)
        if ck.get('format')!=MODEL_FORMAT or ck['metadata']!=meta:raise ValueError('Checkpoint model/data mismatch. Choose a new run folder.')
        for k,v in asdict(cfg).items():
            if k not in ('max_epochs','patience','preview_every') and ck['config'][k]!=v:raise ValueError(f'Resume config changed: {k}')
        model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);scheduler.load_state_dict(ck['scheduler']);history=ck['history'];best=ck['best'];bad=ck['bad'];start=ck['epoch']+1
        torch.set_rng_state(ck['rng']['torch']);random.setstate(ck['rng']['python']);n=ck['rng']['numpy'];np.random.set_state((n[0],np.array(n[1],dtype=np.uint32),n[2],n[3],n[4]))
        if device.type=='cuda' and ck['rng']['cuda']:torch.cuda.set_rng_state_all(ck['rng']['cuda'])
    elif (out/'last.pt').exists():raise FileExistsError('Resume or choose a new run directory.')
    (out/'config.json').write_text(json.dumps(asdict(cfg),indent=2));(out/'metadata.json').write_text(json.dumps(meta,indent=2))
    for epoch in range(start,cfg.max_epochs):
        t=time.monotonic();model.train();indices=np.random.permutation(len(tr));total=0
        for i in range(0,len(tr),cfg.batch_size):
            rows=[tr[k] for k in indices[i:i+cfg.batch_size]];x,g=batch(rows,device);pred,mu,lv=model(x,g);loss=objective(model,x,g,pred,mu,lv)
            if not torch.isfinite(loss):raise FloatingPointError('Non-finite loss')
            opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();total+=float(loss.detach())*len(rows)
        metrics=evaluate(model,val,device);score=metrics['rmse'];scheduler.step(score);improved=score<best-1e-5
        if improved:best=score;bad=0
        else:bad+=1
        bank=build_latent_bank(model,tr,device)
        row={'epoch':epoch+1,'train_objective':total/len(tr),'validation':metrics,'seconds':time.monotonic()-t,'lr':opt.param_groups[0]['lr']};history.append(row)
        if (epoch+1)%cfg.preview_every==0 or epoch+1==cfg.max_epochs or bad>=cfg.patience:
            fig,_=comparison(model,meta,bank,records,chars='abgijAM7');fig.savefig(out/f'preview-{epoch+1:04d}.png',dpi=110,bbox_inches='tight')
            import matplotlib.pyplot as plt
            plt.close(fig)
        ns=np.random.get_state();rng={'torch':torch.get_rng_state(),'python':random.getstate(),'numpy':(ns[0],ns[1].tolist(),ns[2],ns[3],ns[4]),'cuda':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}
        ck={'format':MODEL_FORMAT,'config':asdict(cfg),'metadata':meta,'model':model.state_dict(),'optimizer':opt.state_dict(),'scheduler':scheduler.state_dict(),'epoch':epoch,'history':history,'best':best,'bad':bad,'bank':bank,'rng':rng,'torch_version':str(torch.__version__)}
        common.atomic_save(ck,out/'last.pt')
        if improved:common.atomic_save(ck,out/'best.pt')
        (out/'history.json').write_text(json.dumps(history,indent=2))
        if (epoch+1)%10==0 or epoch==start:print(f"Epoch {epoch+1:3d} | val reconstruction RMSE {score:.4f} | mean-shape baseline {metrics['mean_shape_rmse']:.4f} | {row['seconds']:.2f}s",flush=True)
        if bad>=cfg.patience:print('Early stopping. Inspect generated previews.');break
    return history
