"""Character-conditioned GRU/mixture-density stroke generator for Ink Study.
A small-data experiment trained from scratch, not a pretrained model.
"""
from pathlib import Path
from dataclasses import dataclass, asdict
import copy, hashlib, json, math, random, time, os, platform
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import Dataset, DataLoader

DRAW, MOVE, END = 0, 1, 2

def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

@dataclass
class Config:
    seed: int = 2026
    hidden: int = 192
    layers: int = 2
    embedding: int = 32
    mixtures: int = 10
    dropout: float = 0.15
    batch_size: int = 32
    learning_rate: float = 0.001
    weight_decay: float = 0.0001
    max_epochs: int = 200
    patience: int = 30
    max_steps: int = 256
    spatial_step: float = 0.06
    augment: bool = True
    workers: int = 0
    pressure_weight: float = 0.05

def bounds(sample):
    ps=[p for s in sample['strokes'] for p in s['points']]
    return min(p['x'] for p in ps),min(p['y'] for p in ps),max(p['x'] for p in ps),max(p['y'] for p in ps)

def clean_points(points):
    seen={}
    for p in points:
        key=tuple(p.get(k,0) for k in ('t','x','y','pressure','tiltX','tiltY'))
        seen.setdefault(key,p)
    result=[]
    for p in sorted(seen.values(),key=lambda p:p['t']):
        if not result or math.hypot(p['x']-result[-1]['x'],p['y']-result[-1]['y'])>1e-5:
            result.append(p)
    return result

def resample(stroke,step):
    if len(stroke)<2:return stroke.copy()
    lengths=np.linalg.norm(np.diff(stroke[:,:2],axis=0),axis=1)
    distance=np.r_[0,np.cumsum(lengths)]
    keep=np.r_[True,np.diff(distance)>1e-8]
    stroke,distance=stroke[keep],distance[keep]
    if len(stroke)<2:return stroke.copy()
    positions=np.r_[np.arange(0,distance[-1],step),distance[-1]]
    return np.stack([np.interp(positions,distance,stroke[:,k]) for k in range(3)],axis=1).astype('float32')

def prepare_data(path,config):
    raw=Path(path).read_bytes();dataset=json.loads(raw);samples=copy.deepcopy(dataset['samples'])
    assert len({s['id'] for s in samples})==len(samples),'Duplicate sample IDs'
    groups={}
    for s in samples:
        if len(s['label'])!=1:raise ValueError('This model accepts isolated-character samples only.')
        for st in s['strokes']:
            st['points']=clean_points(st['points'])
            for p in st['points']:
                if not all(math.isfinite(p[k]) for k in ('x','y','t','pressure')):raise ValueError('Non-finite point')
        s['strokes']=[st for st in s['strokes'] if st['points']]
        if not s['strokes']:raise ValueError('Empty sample')
        groups.setdefault(s['label'],[]).append(s)
    # Split originals before augmentation. Never derive normalization from held-out data.
    for examples in groups.values():
        examples.sort(key=lambda s:hashlib.sha256(s['id'].encode()).hexdigest())
        for i,s in enumerate(examples):
            s['split']='test' if len(examples)>=6 and i==0 else 'validation' if len(examples)>=6 and i==1 else 'train'
    reference=[s for s in samples if s['split']=='train' and s['label'] in 'acemnorsuvwxz']
    if not reference:raise ValueError('Need ordinary lowercase training examples for normalization')
    xheight=float(np.median([bounds(s)[3]-bounds(s)[1] for s in reference]))
    baseline=float(np.median([bounds(s)[3] for s in reference]))
    vocab=sorted(groups);records=[]
    for s in samples:
        xmin,ymin,xmax,ymax=bounds(s)
        anchor=ymin+xheight if s['label'] in 'gjpqy' else ymax if s['label'].isalnum() else baseline
        strokes=[np.array([[(p['x']-xmin)/xheight,(p['y']-anchor)/xheight,np.clip(p['pressure'],0,1)] for p in st['points']],dtype='float32') for st in s['strokes']]
        step=config.spatial_step
        for _ in range(30):
            sampled=[resample(st,step) for st in strokes]
            if sum(len(st) for st in sampled)+1<=config.max_steps:break
            step*=1.15
        else:raise ValueError('Too many strokes; increase max_steps')
        records.append({'id':s['id'],'label':s['label'],'class_id':vocab.index(s['label']),'split':s['split'],'strokes':sampled,'session':s.get('sessionId')})
    meta={'schema_version':1,'source_sha256':hashlib.sha256(raw).hexdigest(),'vocab':vocab,'xheight':xheight,'baseline':baseline,'state_semantics':{'0':'draw to destination','1':'move to destination without ink','2':'end; no geometry'},'coordinate_scale':'one x-height unit','sessions':len({s.get('sessionId') for s in samples}),'splits':{r['id']:r['split'] for r in records}}
    return records,meta

def sequence(strokes):
    xyz=[];states=[]
    for stroke in strokes:
        for j,p in enumerate(stroke):xyz.append(p);states.append(MOVE if j==0 else DRAW)
    # Every point is a destination. The first point of each stroke is MOVE.
    # EOS repeats the last coordinate; its geometry is excluded from loss.
    xyz=np.array(xyz,dtype='float32');xyz=np.vstack([xyz,xyz[-1]])
    states=np.r_[states,END].astype('int64')
    delta=np.diff(np.vstack([np.zeros((1,2),dtype='float32'),xyz[:,:2]]),axis=0)
    features=np.concatenate([delta,xyz[:,:2],np.eye(3,dtype='float32')[states],xyz[:,2:3]],axis=1)
    previous=np.zeros_like(features);previous[0,4+MOVE]=1;previous[1:]=features[:-1]
    return torch.tensor(previous),torch.tensor(delta),torch.tensor(states),torch.tensor(xyz[:,2])

class StrokeDataset(Dataset):
    def __init__(self,records,augment=False):self.records=records;self.augment=augment
    def __len__(self):return len(self.records)
    def __getitem__(self,i):
        r=self.records[i];strokes=[s.copy() for s in r['strokes']]
        if self.augment:
            # Mild coherent transforms only, applied to training examples after splitting.
            sx,sy=np.random.uniform(.94,1.06,2);shear=np.random.uniform(-.035,.035)
            for st in strokes:
                st[:,0]=st[:,0]*sx+st[:,1]*shear;st[:,1]*=sy
        return (*sequence(strokes),r['class_id'])

def collate(items):
    lengths=torch.tensor([len(i[0]) for i in items]);n=len(items);t=int(lengths.max())
    inputs=torch.zeros(n,t,8);xy=torch.zeros(n,t,2);states=torch.full((n,t),END,dtype=torch.long);pressure=torch.zeros(n,t)
    for k,(a,b,c,d,_) in enumerate(items):
        length=len(a);inputs[k,:length]=a;xy[k,:length]=b;states[k,:length]=c;pressure[k,:length]=d
    mask=torch.arange(t)[None,:]<lengths[:,None]
    return inputs,xy,states,pressure,torch.tensor([i[-1] for i in items]),mask

class StrokeModel(nn.Module):
    def __init__(self,classes,config):
        super().__init__();self.config=config
        self.embedding=nn.Embedding(classes,config.embedding)
        self.rnn=nn.GRU(8+config.embedding,config.hidden,config.layers,batch_first=True,dropout=config.dropout if config.layers>1 else 0)
        self.head=nn.Linear(config.hidden,config.mixtures*6+4)
    def forward(self,x,char,h=None):
        emb=self.embedding(char)[:,None,:].expand(-1,x.shape[1],-1)
        out,h=self.rnn(torch.cat([x,emb],dim=-1),h)
        raw=self.head(out);k=self.config.mixtures
        mix=raw[...,:k*6].reshape(*raw.shape[:-1],k,6)
        return {'logits':mix[...,0],'mu':mix[...,1:3],'log_sigma':mix[...,3:5].clamp(-5,1.5),'rho':mix[...,5].tanh()*.95,'state':raw[...,k*6:k*6+3],'pressure':raw[...,-1].sigmoid()},h

def objective(pred,xy,states,pressure,mask,pressure_weight=.05):
    sigma=pred['log_sigma'].exp();z=(xy.unsqueeze(-2)-pred['mu'])/sigma
    rho=pred['rho'];one=(1-rho.square()).clamp_min(.01)
    logp=-math.log(2*math.pi)-pred['log_sigma'].sum(-1)-.5*one.log()-(z[...,0].square()+z[...,1].square()-2*rho*z[...,0]*z[...,1])/(2*one)
    nll=-torch.logsumexp(F.log_softmax(pred['logits'],dim=-1)+logp,dim=-1)
    geom=mask & (states!=END)
    xy_loss=(nll*geom).sum()/geom.sum().clamp_min(1)
    # Give each sample equal weight for pen states; rare states need explicit weighting.
    state_losses=F.cross_entropy(pred['state'].transpose(1,2),states,reduction='none',weight=xy.new_tensor([1.,2.,2.]))
    state_loss=(state_losses*mask).sum()/mask.sum()
    pressure_loss=((pred['pressure']-pressure).square()*geom).sum()/geom.sum().clamp_min(1)
    loss=xy_loss+state_loss+pressure_weight*pressure_loss
    accuracy=(((pred['state'].argmax(-1)==states)&mask).sum()/mask.sum()).item()
    return loss,{'loss':loss.item(),'xy_nll':xy_loss.item(),'pen_ce':state_loss.item(),'pressure_mse':pressure_loss.item(),'pen_accuracy':accuracy}

def make_loaders(records,config):
    return {split:DataLoader(StrokeDataset([r for r in records if r['split']==split],config.augment and split=='train'),batch_size=config.batch_size,shuffle=split=='train',num_workers=config.workers,collate_fn=collate,pin_memory=torch.cuda.is_available()) for split in ('train','validation','test')}

def run_epoch(model,loader,device,optimizer=None):
    model.train(optimizer is not None);totals={};count=0
    for batch in loader:
        x,xy,states,pressure,char,mask=[v.to(device) for v in batch]
        with torch.set_grad_enabled(optimizer is not None):
            pred,_=model(x,char);loss,metrics=objective(pred,xy,states,pressure,mask,model.config.pressure_weight)
            if not torch.isfinite(loss):raise FloatingPointError('Non-finite loss; reduce learning rate and inspect samples')
            if optimizer is not None:
                optimizer.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.0);optimizer.step()
        n=len(x);count+=n
        for k,v in metrics.items():totals[k]=totals.get(k,0)+v*n
    if not count:raise ValueError('Empty split')
    return {k:v/count for k,v in totals.items()}

def atomic_save(payload,path):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');torch.save(payload,tmp);os.replace(tmp,path)

def fit(model,loaders,meta,config,output_dir,device,resume=None,callback=None):
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    optimizer=torch.optim.AdamW(model.parameters(),lr=config.learning_rate,weight_decay=config.weight_decay)
    scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer,patience=8,factor=.5)
    history=[];best=float('inf');bad=0;start=0
    if resume:
        ck=torch.load(resume,map_location='cpu',weights_only=True)
        if ck['metadata']!=meta:raise ValueError('Resume data/splits/vocabulary mismatch. Use a new output directory.')
        allowed_changes={'max_epochs','patience','workers'}
        if any(ck['config'][k]!=v for k,v in asdict(config).items() if k not in allowed_changes):raise ValueError('Resume config changed; only max_epochs, patience and workers may change.')
        model.load_state_dict(ck['model']);optimizer.load_state_dict(ck['optimizer']);scheduler.load_state_dict(ck['scheduler'])
        for state in optimizer.state.values():
            for k,v in state.items():
                if torch.is_tensor(v):state[k]=v.to(device)
        history=ck['history'];best=ck['best'];bad=ck['bad_epochs'];start=ck['epoch']+1
        torch.set_rng_state(ck['torch_rng']);random.setstate(ck['python_rng'])
        ns=ck['numpy_rng'];np.random.set_state((ns[0],np.array(ns[1],dtype=np.uint32),ns[2],ns[3],ns[4]))
        if device.type=='cuda' and ck.get('cuda_rng'):torch.cuda.set_rng_state_all(ck['cuda_rng'])
    elif (output_dir/'last.pt').exists():raise FileExistsError('Run directory exists. Set RESUME to last.pt or choose a new run directory.')
    model.to(device)
    (output_dir/'metadata.json').write_text(json.dumps(meta,indent=2))
    (output_dir/'config.json').write_text(json.dumps(asdict(config),indent=2))
    for epoch in range(start,config.max_epochs):
        t0=time.monotonic();tr=run_epoch(model,loaders['train'],device,optimizer);val=run_epoch(model,loaders['validation'],device)
        scheduler.step(val['loss']);improved=val['loss']<best-1e-4
        if improved:best=val['loss'];bad=0
        else:bad+=1
        row={'epoch':epoch+1,'seconds':time.monotonic()-t0,'lr':optimizer.param_groups[0]['lr'],'train':tr,'validation':val};history.append(row)
        ns=np.random.get_state()
        ck={'format_version':1,'model':model.state_dict(),'optimizer':optimizer.state_dict(),'scheduler':scheduler.state_dict(),'config':asdict(config),'metadata':meta,'epoch':epoch,'best':best,'bad_epochs':bad,'history':history,'torch_rng':torch.get_rng_state(),'python_rng':random.getstate(),'numpy_rng':(ns[0],ns[1].tolist(),ns[2],ns[3],ns[4]),'cuda_rng':torch.cuda.get_rng_state_all() if device.type=='cuda' else [],'environment':{'torch':str(torch.__version__),'numpy':str(np.__version__),'python':platform.python_version()}}
        atomic_save(ck,output_dir/'last.pt')
        if improved:atomic_save(ck,output_dir/'best.pt')
        (output_dir/'history.json').write_text(json.dumps(history,indent=2))
        print(f"Epoch {epoch+1:3d} | train {tr['loss']:.3f} | val {val['loss']:.3f} | {row['seconds']:.1f}s",flush=True)
        # Callback must not change training RNG or weights. Notebook callback only plots history.
        if callback:callback(history)
        if bad>=config.patience:print('Early stopping. Best checkpoint preserved.');break
    return history

def load_model(path,device='cpu'):
    ck=torch.load(path,map_location='cpu',weights_only=True);cfg=Config(**ck['config'])
    model=StrokeModel(len(ck['metadata']['vocab']),cfg);model.load_state_dict(ck['model']);model.to(device).eval()
    return model,ck['metadata'],ck

@torch.inference_mode()
def generate(model,meta,char,seed=1,temperature=.35,max_steps=None):
    if char not in meta['vocab']:raise ValueError(f'No training character: {char!r}')
    if not 0<temperature<=1.5:raise ValueError('Use temperature in (0, 1.5]')
    device=next(model.parameters()).device;was_training=model.training;model.eval()
    rng=torch.Generator(device=device);rng.manual_seed(seed)
    current=torch.zeros(1,1,8,device=device);current[0,0,4+MOVE]=1
    char_id=torch.tensor([meta['vocab'].index(char)],device=device);h=None;pos=torch.zeros(2,device=device)
    strokes=[];stroke=[];stop='max_steps'
    for step in range(max_steps or model.config.max_steps):
        pred,h=model(current,char_id,h)
        probs=F.softmax(pred['state'][0,0]/temperature,dim=-1)
        # A valid sequence starts with a pen move. Thereafter let the model decide.
        state=MOVE if step==0 else int(torch.multinomial(probs,1,generator=rng))
        if state==END:stop='end';break
        weights=F.softmax(pred['logits'][0,0]/temperature,dim=-1)
        k=int(torch.multinomial(weights,1,generator=rng));mu=pred['mu'][0,0,k];sigma=pred['log_sigma'][0,0,k].exp()*math.sqrt(temperature);rho=pred['rho'][0,0,k]
        eps=torch.randn(2,generator=rng,device=device);noise=torch.stack([eps[0],rho*eps[0]+torch.sqrt(1-rho*rho)*eps[1]])
        delta=mu+sigma*noise;pos=pos+delta
        if not torch.isfinite(pos).all() or pos.abs().max()>8:stop='out_of_bounds';break
        pressure=float(pred['pressure'][0,0]);point=[float(pos[0]),float(pos[1]),pressure]
        if state==MOVE and stroke:strokes.append(np.array(stroke,dtype='float32'));stroke=[]
        stroke.append(point)
        current=torch.zeros(1,1,8,device=device);current[0,0,:2]=delta;current[0,0,2:4]=pos;current[0,0,4+state]=1;current[0,0,7]=pressure
    if stroke:strokes.append(np.array(stroke,dtype='float32'))
    model.train(was_training)
    return {'label':char,'seed':seed,'temperature':temperature,'strokes':strokes,'stop':stop,'points':sum(len(s) for s in strokes)}

def plot_strokes(ax,strokes,title=''):
    for s in strokes:
        if len(s)==1:ax.plot(s[:,0],s[:,1],'.',color='#192b48',markersize=2)
        else:ax.plot(s[:,0],s[:,1],color='#192b48',linewidth=1.3)
    ax.set_title(title,fontsize=10);ax.set_aspect('equal');ax.invert_yaxis();ax.axis('off')

def comparison(model,meta,records,chars='abcgAM37',seed=11,temperature=.35):
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(len(chars),4,figsize=(9,2*len(chars)),squeeze=False)
    diagnostics=[]
    for row,char in enumerate(chars):
        candidates=[r for r in records if r['label']==char and r['split']=='train']
        held=[r for r in records if r['label']==char and r['split']=='validation']
        plot_strokes(axes[row,0],candidates[0]['strokes'],f'{char}: train original')
        if held:plot_strokes(axes[row,1],held[0]['strokes'],'validation original')
        else:axes[row,1].axis('off')
        for col in (2,3):
            generated=generate(model,meta,char,seed+row*2+col,temperature)
            plot_strokes(axes[row,col],generated['strokes'],f"generated · {generated['stop']}")
            diagnostics.append({k:v for k,v in generated.items() if k!='strokes'})
    fig.tight_layout();return fig,diagnostics

def svg_text(model,meta,text,seed=1,temperature=.35,size=24,width=840,margin=55):
    # Separate-print layout is heuristic. Raw generation diagnostics are always returned.
    import re
    unknown=sorted(set(text)-set(meta['vocab'])-set(' \n\t\r'))
    if unknown:raise ValueError(f'Unsupported characters: {unknown}')
    x=margin;y=margin+size*2.8;line_height=size*4.2;paths=[];diagnostics=[];counter=0
    def newline():
        nonlocal x,y;x=margin;y+=line_height
    for token in re.findall(r'\n|[^\S\n]+|[^\s]+',text.replace('\r','')):
        if token=='\n':newline();continue
        if token.isspace():x+=size*.8*len(token);continue
        glyphs=[]
        for char in token:
            g=generate(model,meta,char,seed+counter,temperature);counter+=1
            diagnostics.append({k:v for k,v in g.items() if k!='strokes'})
            if not g['strokes']:raise RuntimeError(f'Model generated an empty {char!r}; inspect character sheet before exporting.')
            points=np.concatenate(g['strokes']);xmin,ymin=points[:,:2].min(0);xmax,ymax=points[:,:2].max(0)
            # Same alignment policy as preprocessing. Never connect pen-up segments.
            anchor=ymin+1 if char in 'gjpqy' else ymax if char.isalnum() else 0
            adjusted=[s.copy() for s in g['strokes']]
            for s in adjusted:s[:,0]-=xmin;s[:,1]-=anchor
            glyphs.append((adjusted,max(.15,float(xmax-xmin))*size+size*.22))
        if x>margin and x+sum(w for _,w in glyphs)>width-margin:newline()
        for strokes,advance in glyphs:
            if x>margin and x+advance>width-margin:newline()
            for stroke in strokes:
                coords=[(x+float(p[0])*size,y+float(p[1])*size) for p in stroke]
                if len(coords)==1:paths.append(f'<circle cx="{coords[0][0]:.2f}" cy="{coords[0][1]:.2f}" r=".7"/>')
                else:
                    d='M'+' L'.join(f'{a:.2f},{b:.2f}' for a,b in coords)
                    paths.append(f'<path d="{d}" fill="none" stroke="#182235" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>')
            x+=advance
    height=max(400,int(y+size*2+margin));svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="white"/>'+''.join(paths)+'</svg>'
    return svg,diagnostics
